const translate = new Object();

translate.name = "Name";
translate.job = "Job";
translate.bank = "Bank";
translate.money = "Cash";
translate.gender = "Gender";
translate.dob = "Date of birth";

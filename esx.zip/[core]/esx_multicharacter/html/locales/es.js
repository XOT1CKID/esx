const translate = new Object();

translate.name = "Nombre";
translate.job = "Trabajo";
translate.bank = "Banco";
translate.money = "Dinero";
translate.gender = "Género";
translate.dob = "Fecha de nacimiento";

Locales["pt"] = {
  ["skin_menu"] = "Menu de Skin",
  ["use_rotate_view"] = "Usa ~INPUT_FRONTEND_LS~ e ~INPUT_CHARACTER_WHEEL~ para rodar a câmara.",
  ["skin"] = "alterar skin",
  ["saveskin"] = "salvar a skin num ficheiro",
}

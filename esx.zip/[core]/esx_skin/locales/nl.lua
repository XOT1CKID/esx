Locales["nl"] = {
  ["skin_menu"] = "Kleding Menu",
  ["use_rotate_view"] = "gebruik ~INPUT_FRONTEND_LS~ en ~INPUT_CHARACTER_WHEEL~ om de camera te draaien.",
  ["skin"] = "verander outfit",
  ["saveskin"] = "sla outfit op in je kledingkast.",
}

Locales["zh-cn"] = {
  ["skin_menu"] = "皮肤选单",
  ["use_rotate_view"] = "使用 ~INPUT_FRONTEND_LS~ 和 ~INPUT_CHARACTER_WHEEL~ 旋转镜头视角.",
  ["skin"] = "更换皮肤数据",
  ["saveskin"] = "保存皮肤数据",
}

Locales["sl"] = {
  ["skin_menu"] = "Oblacilni menu.",
  ["use_rotate_view"] = "Pritisni ~INPUT_FRONTEND_LS~ in ~INPUT_CHARACTER_WHEEL~ da se obracas s pogledom.",
  ["skin"] = "Zamenjaj Skin.",
  ["saveskin"] = "Shrani skin.",
}
